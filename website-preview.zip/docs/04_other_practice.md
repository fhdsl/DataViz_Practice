# Other ways to practice



## Learning Objectives

This chapter will cover:

- {LO1}
- {LO2}


## Bioviz data visualization challenges
## Plotnine Contest Gallery
## Case studies from the Fred Hutch Data Visualization Center
