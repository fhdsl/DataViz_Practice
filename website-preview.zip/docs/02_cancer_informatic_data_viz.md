# Data Visualization for Cancer Informatics



## Learning Objectives

This chapter will cover:

- {LO1}
- {LO2}

## Common types of Cancer Data
## Common research questions when working with cancer data
## Most common graph types in cancer informatics
## Available technologies for data visualizations in cancer informatics
